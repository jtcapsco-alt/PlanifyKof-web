﻿// ============================================================
// EDGE FUNCTION: verificar-biometria
// ------------------------------------------------------------
// Maneja las 4 operaciones de WebAuthn (registro y login de
// biometría) usando @simplewebauthn/server (verificación
// criptográfica real, no un atajo).
//
// Se llama con POST y un body JSON: { "action": "...", ... }
// Acciones soportadas:
//   - "opciones-registro"   -> genera el challenge para activar biometría
//   - "verificar-registro"  -> confirma que la huella/Face ID fue real
//   - "opciones-login"      -> genera el challenge para iniciar sesión
//   - "verificar-login"     -> confirma el login con biometría
// ============================================================

import {
  generateRegistrationOptions,
  verifyRegistrationResponse,
  generateAuthenticationOptions,
  verifyAuthenticationResponse,
} from "npm:@simplewebauthn/server@13";
import { isoBase64URL } from "npm:@simplewebauthn/server@13/helpers";
import { createClient } from "npm:@supabase/supabase-js@2";

// --- Configuración fija del dominio (Relying Party) ---
const RP_NAME = "PlanifyKOF";
const RP_ID = "jtcapsco-alt.github.io";
const ORIGIN = "https://jtcapsco-alt.github.io";

// --- Cliente de Supabase con permisos completos (llave de servicio) ---
const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

// --- Encabezados CORS (la página HTML vive en un dominio distinto) ---
const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function respuesta(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: CORS_HEADERS });
  }

  try {
    const body = await req.json();
    const { action, usuario_id } = body;

    // ============================================================
    // 1) OPCIONES DE REGISTRO (activar biometría por primera vez)
    // ============================================================
    if (action === "opciones-registro") {
      const { data: usuario, error: errUsuario } = await supabase
        .from("usuarios")
        .select("id, nombre_completo, codigo")
        .eq("id", usuario_id)
        .single();

      if (errUsuario || !usuario) {
        return respuesta({ error: "Usuario no encontrado" }, 404);
      }

      const { data: dispositivosExistentes } = await supabase
        .from("dispositivos_biometricos")
        .select("credential_id")
        .eq("usuario_id", usuario_id)
        .eq("activo", true);

      const excludeCredentials = (dispositivosExistentes ?? []).map((d) => ({
        id: d.credential_id,
      }));

      const options = await generateRegistrationOptions({
        rpName: RP_NAME,
        rpID: RP_ID,
        userName: usuario.codigo ?? String(usuario.id),
        userID: new TextEncoder().encode(String(usuario.id)),
        attestationType: "none",
        excludeCredentials,
        authenticatorSelection: {
          residentKey: "preferred",
          userVerification: "required",
        },
      });

      await supabase.from("biometria_challenges").insert({
        usuario_id,
        challenge: options.challenge,
        tipo: "registro",
      });

      return respuesta(options);
    }

    // ============================================================
    // 2) VERIFICAR REGISTRO (confirmar que la huella/Face ID fue real)
    // ============================================================
    if (action === "verificar-registro") {
      const { response, nombre_dispositivo, plataforma } = body;

      const { data: challengeRow, error: errChallenge } = await supabase
        .from("biometria_challenges")
        .select("*")
        .eq("usuario_id", usuario_id)
        .eq("tipo", "registro")
        .eq("usado", false)
        .gt("expira_en", new Date().toISOString())
        .order("creado_en", { ascending: false })
        .limit(1)
        .single();

      if (errChallenge || !challengeRow) {
        return respuesta({ error: "Challenge inválido o vencido, intenta de nuevo" }, 400);
      }

      const verification = await verifyRegistrationResponse({
        response,
        expectedChallenge: challengeRow.challenge,
        expectedOrigin: ORIGIN,
        expectedRPID: RP_ID,
      });

      if (!verification.verified || !verification.registrationInfo) {
        return respuesta({ verified: false });
      }

      const { credential } = verification.registrationInfo;

      await supabase.from("dispositivos_biometricos").insert({
        usuario_id,
        credential_id: credential.id,
        public_key: isoBase64URL.fromBuffer(credential.publicKey),
        counter: credential.counter,
        nombre_dispositivo: nombre_dispositivo ?? null,
        plataforma: plataforma ?? null,
      });

      await supabase
        .from("biometria_challenges")
        .update({ usado: true })
        .eq("id", challengeRow.id);

      return respuesta({ verified: true });
    }

    // ============================================================
    // 3) OPCIONES DE LOGIN (usar biometría para entrar)
    // ============================================================
    if (action === "opciones-login") {
      const { data: dispositivos } = await supabase
        .from("dispositivos_biometricos")
        .select("credential_id")
        .eq("usuario_id", usuario_id)
        .eq("activo", true);

      if (!dispositivos || dispositivos.length === 0) {
        return respuesta({ error: "Este usuario no tiene biometría activada" }, 400);
      }

      const options = await generateAuthenticationOptions({
        rpID: RP_ID,
        allowCredentials: dispositivos.map((d) => ({ id: d.credential_id })),
        userVerification: "required",
      });

      await supabase.from("biometria_challenges").insert({
        usuario_id,
        challenge: options.challenge,
        tipo: "login",
      });

      return respuesta(options);
    }

    // ============================================================
    // 4) VERIFICAR LOGIN (confirmar el ingreso con biometría)
    // ============================================================
    if (action === "verificar-login") {
      const { response } = body;

      const { data: challengeRow, error: errChallenge } = await supabase
        .from("biometria_challenges")
        .select("*")
        .eq("usuario_id", usuario_id)
        .eq("tipo", "login")
        .eq("usado", false)
        .gt("expira_en", new Date().toISOString())
        .order("creado_en", { ascending: false })
        .limit(1)
        .single();

      if (errChallenge || !challengeRow) {
        return respuesta({ error: "Challenge inválido o vencido, intenta de nuevo" }, 400);
      }

      const { data: dispositivo, error: errDispositivo } = await supabase
        .from("dispositivos_biometricos")
        .select("*")
        .eq("usuario_id", usuario_id)
        .eq("credential_id", response.id)
        .eq("activo", true)
        .single();

      if (errDispositivo || !dispositivo) {
        return respuesta({ error: "Dispositivo no reconocido" }, 400);
      }

      const verification = await verifyAuthenticationResponse({
        response,
        expectedChallenge: challengeRow.challenge,
        expectedOrigin: ORIGIN,
        expectedRPID: RP_ID,
        credential: {
          id: dispositivo.credential_id,
          publicKey: isoBase64URL.toBuffer(dispositivo.public_key),
          counter: dispositivo.counter,
        },
        requireUserVerification: true,
      });

      if (!verification.verified) {
        return respuesta({ verified: false });
      }

      await supabase
        .from("dispositivos_biometricos")
        .update({
          counter: verification.authenticationInfo.newCounter,
          ultimo_uso: new Date().toISOString(),
        })
        .eq("id", dispositivo.id);

      await supabase
        .from("biometria_challenges")
        .update({ usado: true })
        .eq("id", challengeRow.id);

      const { data: usuario } = await supabase
        .from("usuarios")
        .select("id, nombre_completo, codigo, rol, linea_id")
        .eq("id", usuario_id)
        .single();

      return respuesta({ verified: true, usuario });
    }

    return respuesta({ error: "Acción no reconocida: " + action }, 400);
  } catch (err) {
    return respuesta({ error: String(err) }, 500);
  }
});
